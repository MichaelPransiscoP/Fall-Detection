import os
import argparse
import random
from typing import List, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, Subset


# ============================================================
# 1. Dataset: NPZ -> sequence (T, input_size)
# ============================================================

class NpzSequenceDataset(Dataset):
    """
    Dataset untuk file NPZ:
    - Setiap .npz diasumsikan berisi array dengan shape (T, K, C)
      di mana C >= 2 (x, y, [confidence]).
    - Diambil hanya (x, y) lalu di-flatten per frame -> (T, K*2).
    - Dilakukan padding/trunc ke max_len agar panjang sama.
    """
    def __init__(self,
                 fall_dir: str,
                 non_dir: str,
                 max_len: int = None):
        super().__init__()

        self.samples: List[np.ndarray] = []
        self.labels: List[int] = []   # FALL=1, ADL=0
        self.paths: List[str] = []

        # ----------------------------------------------------
        # Kumpulkan semua file NPZ
        # ----------------------------------------------------
        fall_files = sorted([
            os.path.join(fall_dir, f)
            for f in os.listdir(fall_dir)
            if f.lower().endswith(".npz")
        ])
        adl_files = sorted([
            os.path.join(non_dir, f)
            for f in os.listdir(non_dir)
            if f.lower().endswith(".npz")
        ])

        print(f"Jumlah file: FALL={len(fall_files)} | ADL={len(adl_files)}")

        # Load FALL
        for fp in fall_files:
            arr = np.load(fp, allow_pickle=True)
            # Asumsi data utama di key "arr_0"
            data = arr[list(arr.files)[0]]
            if data.ndim != 3:
                continue
            self.samples.append(data)
            self.labels.append(1)
            self.paths.append(os.path.basename(fp))

        # Load ADL
        for fp in adl_files:
            arr = np.load(fp, allow_pickle=True)
            data = arr[list(arr.files)[0]]
            if data.ndim != 3:
                continue
            self.samples.append(data)
            self.labels.append(0)
            self.paths.append(os.path.basename(fp))

        if len(self.samples) == 0:
            raise RuntimeError("Tidak ada data NPZ yang valid ditemukan.")

        # ----------------------------------------------------
        # Tentukan max_len otomatis kalau tidak diberikan
        # ----------------------------------------------------
        if max_len is None:
            lens = [s.shape[0] for s in self.samples]
            self.max_len = max(lens)
        else:
            self.max_len = max_len

        # Input size = K * 2 (x, y)
        example = self.samples[0]
        if example.shape[2] < 2:
            raise RuntimeError("Channel terakhir < 2, tidak ada (x, y).")

        self.K = example.shape[1]
        self.input_size = self.K * 2

        print(f"Total sampel: {len(self.samples)} | input_size: {self.input_size}")

    def __len__(self):
        return len(self.samples)

    def _to_xy_flat(self, data: np.ndarray) -> np.ndarray:
        """
        data: (T, K, C) -> ambil (x, y) -> (T, K*2)
        """
        T, K, C = data.shape
        xy = data[:, :, :2]  # ambil x,y
        seq = xy.reshape(T, K * 2)
        return seq

    def _pad_trunc(self, seq: np.ndarray) -> np.ndarray:
        """
        Pad/trunc sequence (T, input_size) ke (max_len, input_size).
        """
        T, D = seq.shape
        if T > self.max_len:
            return seq[:self.max_len, :]
        elif T < self.max_len:
            pad = np.zeros((self.max_len - T, D), dtype=seq.dtype)
            return np.concatenate([seq, pad], axis=0)
        else:
            return seq

    def __getitem__(self, idx: int):
        data = self.samples[idx]   # (T, K, C)
        label = self.labels[idx]
        path = self.paths[idx]

        seq = self._to_xy_flat(data)     # (T, input_size)
        seq = self._pad_trunc(seq)       # (max_len, input_size)

        x = torch.tensor(seq, dtype=torch.float32)
        y = torch.tensor(label, dtype=torch.float32)

        return x, y, path


# ============================================================
# 2. Model LSTM
# ============================================================

class LSTMFallDetector(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, dropout: float):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            batch_first=True
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (B, T, D)
        out, _ = self.lstm(x)          # (B, T, H)
        last = out[:, -1, :]           # (B, H)
        last = self.dropout(last)
        logits = self.fc(last).squeeze(-1)  # (B,)
        return logits


# ============================================================
# 3. Metric helper
# ============================================================

def compute_confusion_and_metrics(y_true: np.ndarray,
                                  y_prob: np.ndarray,
                                  thresh: float = 0.5):
    """
    y_true: (N,) 0/1
    y_prob: (N,) [0..1]
    """
    y_pred = (y_prob >= thresh).astype(int)

    TP = int(((y_true == 1) & (y_pred == 1)).sum())
    TN = int(((y_true == 0) & (y_pred == 0)).sum())
    FP = int(((y_true == 0) & (y_pred == 1)).sum())
    FN = int(((y_true == 1) & (y_pred == 0)).sum())

    total = len(y_true)
    acc = (TP + TN) / total if total > 0 else 0.0
    sens = TP / (TP + FN) if (TP + FN) > 0 else 0.0
    spec = TN / (TN + FP) if (TN + FP) > 0 else 0.0

    return TP, TN, FP, FN, acc, sens, spec


def eval_loader(model, loader, device):
    model.eval()
    all_probs = []
    all_labels = []
    total_loss = 0.0
    total_count = 0

    criterion = nn.BCEWithLogitsLoss()

    with torch.no_grad():
        for x, y, _ in loader:
            x = x.to(device)
            y = y.to(device)

            logits = model(x)
            loss = criterion(logits, y)
            total_loss += loss.item() * y.size(0)
            total_count += y.size(0)

            probs = torch.sigmoid(logits).cpu().numpy()
            labels = y.cpu().numpy()

            all_probs.append(probs)
            all_labels.append(labels)

    if total_count == 0:
        return 0.0, 0, 0, 0, 0, 0.0, 0.0, 0.0

    all_probs = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)

    TP, TN, FP, FN, acc, sens, spec = compute_confusion_and_metrics(
        all_labels, all_probs
    )
    avg_loss = total_loss / total_count

    return avg_loss, TP, TN, FP, FN, acc, sens, spec


# ============================================================
# 4. Train + Val + Test dengan split khusus:
#    - Total 70 video
#    - Train 49 video: 21 FALL + 28 ADL
#    - Sisa 21 video → val + test (~10–11)
#    TANPA EARLY STOPPING
# ============================================================

def train_model(fall_dir: str,
                non_dir: str,
                hidden_size: int,
                epochs: int,
                batch_size: int,
                dropout: float,
                out_model: str = None,
                seed: int = 42):

    # Set seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Gunakan device: {device}")

    # --------------------------------------------------------
    # Buat dataset penuh
    # --------------------------------------------------------
    full_dataset = NpzSequenceDataset(fall_dir, non_dir)
    input_size = full_dataset.input_size
    total_samples = len(full_dataset)

    # Cari index FALL dan ADL
    fall_indices = [i for i, y in enumerate(full_dataset.labels) if y == 1]
    adl_indices = [i for i, y in enumerate(full_dataset.labels) if y == 0]

    n_fall = len(fall_indices)
    n_adl = len(adl_indices)

    # Randomize index (biar tidak selalu urut)
    random.shuffle(fall_indices)
    random.shuffle(adl_indices)

    # Pastikan cukup untuk 21 + 28
    if n_fall < 21 or n_adl < 28:
        raise RuntimeError("Butuh minimal 21 FALL dan 28 NON-FALL untuk train.")

    # Train: 21 FALL + 28 ADL
    n_train_fall = 21
    n_train_adl  = 28

    train_fall = fall_indices[:n_train_fall]
    remain_fall = fall_indices[n_train_fall:]

    train_adl = adl_indices[:n_train_adl]
    remain_adl = adl_indices[n_train_adl:]

    train_indices = train_fall + train_adl
    remain_indices = remain_fall + remain_adl

    # Sisa: 9 FALL + 12 ADL = 21 → val + test
    n_remain = len(remain_indices)
    random.shuffle(remain_indices)

    n_val = n_remain // 2          # sekitar 10
    n_test = n_remain - n_val      # sekitar 11

    val_indices = remain_indices[:n_val]
    test_indices = remain_indices[n_val:]

    print(f"Split index: train={len(train_indices)} | val={len(val_indices)} | test={len(test_indices)}")

    # Buat subset
    train_set = Subset(full_dataset, train_indices)
    val_set   = Subset(full_dataset, val_indices)
    test_set  = Subset(full_dataset, test_indices)

    # DataLoader
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader   = DataLoader(val_set, batch_size=batch_size, shuffle=False)
    test_loader  = DataLoader(test_set, batch_size=len(test_set), shuffle=False)

    # --------------------------------------------------------
    # Inisialisasi model + optimizer
    # --------------------------------------------------------
    model = LSTMFallDetector(input_size=input_size,
                             hidden_size=hidden_size,
                             dropout=dropout).to(device)

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    # --------------------------------------------------------
    # Training loop TANPA patience
    # --------------------------------------------------------
    for epoch in range(1, epochs + 1):
        model.train()
        total_train_loss = 0.0
        total_train_count = 0

        all_train_probs = []
        all_train_labels = []

        for x, y, _ in train_loader:
            x = x.to(device)
            y = y.to(device)

            optimizer.zero_grad()
            logits = model(x)
            loss = criterion(logits, y)

            loss.backward()
            optimizer.step()

            total_train_loss += loss.item() * y.size(0)
            total_train_count += y.size(0)

            probs = torch.sigmoid(logits).detach().cpu().numpy()
            labels = y.cpu().numpy()

            all_train_probs.append(probs)
            all_train_labels.append(labels)

        # Hitung metric train
        all_train_probs = np.concatenate(all_train_probs)
        all_train_labels = np.concatenate(all_train_labels)

        train_loss = total_train_loss / total_train_count
        TP_tr, TN_tr, FP_tr, FN_tr, acc_tr, sens_tr, spec_tr = \
            compute_confusion_and_metrics(all_train_labels, all_train_probs)

        # Evaluasi val
        val_loss, TP_v, TN_v, FP_v, FN_v, acc_v, sens_v, spec_v = \
            eval_loader(model, val_loader, device)

        print(
            f"Epoch {epoch:03d} | "
            f"train_loss={train_loss:.4f} acc={acc_tr:.4f} sens={sens_tr:.4f} spec={spec_tr:.4f} || "
            f"val_loss={val_loss:.4f} acc={acc_v:.4f} sens={sens_v:.4f} spec={spec_v:.4f}"
        )
        print(
            f"CM train: TP={TP_tr} TN={TN_tr} FP={FP_tr} FN={FN_tr}\n"
            f"CM val  : TP={TP_v} TN={TN_v} FP={FP_v} FN={FN_v}"
        )
        print("-" * 60)

    # --------------------------------------------------------
    # Simpan model (opsional)
    # --------------------------------------------------------
    if out_model is not None:
        os.makedirs(os.path.dirname(out_model), exist_ok=True)
        torch.save(model.state_dict(), out_model)
        print(f"Model disimpan ke: {out_model}")

    # --------------------------------------------------------
    # Testing (split)
    # --------------------------------------------------------
    print("\n==================== TESTING (SPLIT) ====================")
    test_loss, TP_t, TN_t, FP_t, FN_t, acc_t, sens_t, spec_t = \
        eval_loader(model, test_loader, device)
    print(
        f"TEST | samples={len(test_set)} loss={test_loss:.4f} "
        f"acc={acc_t:.4f} sens={sens_t:.4f} spec={spec_t:.4f}"
    )
    print(f"CM test: TP={TP_t} TN={TN_t} FP={FP_t} FN={FN_t}")
    print("=============================================================\n")

    # --------------------------------------------------------
    # Testing 1–1 per video (mengikuti index di test_indices)
    # --------------------------------------------------------
    print("\n==================== TESTING 1–1 PER VIDEO ====================")
    model.eval()

    correct_total = 0
    total_total = 0

    correct_fall = 0
    total_fall = 0

    correct_adl = 0
    total_adl = 0

    with torch.no_grad():
        for idx in test_indices:
            x, y, path = full_dataset[idx]
            x = x.unsqueeze(0).to(device)  # (1, T, D)
            y = y.item()

            logits = model(x)
            prob = torch.sigmoid(logits).item()
            pred = 1 if prob >= 0.5 else 0

            label_str = "FALL" if y == 1 else "ADL"
            pred_str  = "FALL" if pred == 1 else "ADL"

            benar = (pred == y)
            if benar:
                status = "Benar"
                correct_total += 1
            else:
                status = "Salah"

            total_total += 1

            if y == 1:
                total_fall += 1
                if benar:
                    correct_fall += 1
            else:
                total_adl += 1
                if benar:
                    correct_adl += 1

            print(f"{path:<40} | label={label_str:<4} pred={pred_str:<4} prob={prob:.4f} | {status}")

    acc_fall = correct_fall / total_fall if total_fall > 0 else 0.0
    acc_adl  = correct_adl / total_adl if total_adl > 0 else 0.0
    acc_tot  = correct_total / total_total if total_total > 0 else 0.0

    print("\n-------------------- RINGKASAN 1–1 --------------------")
    print(f"FALL-only | benar {correct_fall} / {total_fall}  -> acc={acc_fall:.4f}")
    print(f"ADL-only  | benar {correct_adl} / {total_adl}   -> acc={acc_adl:.4f}")
    print(f"TOTAL     | benar {correct_total} / {total_total} -> acc={acc_tot:.4f}")
    print("======================================================\n")


# ============================================================
# 5. Main (argparse)
# ============================================================

def main():
    p = argparse.ArgumentParser(
        description="Train LSTM Fall Detection (21 FALL + 28 ADL train, tanpa patience)."
    )
    p.add_argument("--fall_dir", type=str, required=True,
                   help="Folder NPZ untuk kelas FALL (label=1)")
    p.add_argument("--non_dir", type=str, required=True,
                   help="Folder NPZ untuk kelas ADL/NON-FALL (label=0)")
    p.add_argument("--hidden", type=int, default=256,
                   help="Hidden size LSTM")
    p.add_argument("--epochs", type=int, default=100,
                   help="Jumlah epoch training")
    p.add_argument("--batch_size", type=int, default=32,
                   help="Batch size")
    p.add_argument("--dropout", type=float, default=0.2,
                   help="Dropout pada dense head")
    p.add_argument("--out_model", type=str, default=None,
                   help="Path untuk menyimpan model (.pth)")

    args = p.parse_args()

    train_model(
        fall_dir=args.fall_dir,
        non_dir=args.non_dir,
        hidden_size=args.hidden,
        epochs=args.epochs,
        batch_size=args.batch_size,
        dropout=args.dropout,
        out_model=args.out_model
    )


if __name__ == "__main__":
    main()
