import re
import argparse
from pathlib import Path
import matplotlib.pyplot as plt

# Regex yang cocok dengan format log kamu:
# Epoch 001 | train_loss=0.6660 acc=0.7000 ... || val_loss=0.5961 acc=0.8000 ...
LINE_RE = re.compile(
    r"Epoch\s+(?P<epoch>\d+)\s+\|\s+"
    r"train_loss=(?P<train_loss>\d+(?:\.\d+)?)"
    r"(?:\s+acc=(?P<train_acc>\d+(?:\.\d+)?))?"
    r".*?\|\|\s+"
    r"val_loss=(?P<val_loss>\d+(?:\.\d+)?)"
    r"(?:\s+acc=(?P<val_acc>\d+(?:\.\d+)?))?",
    re.IGNORECASE
)

def parse_log(text: str):
    epochs, tr_loss, va_loss, tr_acc, va_acc = [], [], [], [], []
    for line in text.splitlines():
        m = LINE_RE.search(line)
        if not m:
            continue
        epochs.append(int(m.group("epoch")))
        tr_loss.append(float(m.group("train_loss")))
        va_loss.append(float(m.group("val_loss")))

        # acc bisa ada atau tidak
        tr_acc.append(float(m.group("train_acc")) if m.group("train_acc") else None)
        va_acc.append(float(m.group("val_acc")) if m.group("val_acc") else None)

    has_acc = any(v is not None for v in tr_acc) and any(v is not None for v in va_acc)
    if not has_acc:
        tr_acc, va_acc = None, None

    return epochs, tr_loss, va_loss, tr_acc, va_acc

def plot_curves(epochs, tr_loss, va_loss, tr_acc, va_acc, title, out_png: Path):
    # Plot LOSS
    plt.figure()
    plt.plot(epochs, tr_loss, label="train_loss")
    plt.plot(epochs, va_loss, label="val_loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title(f"{title} (Loss)")
    plt.legend()
    plt.tight_layout()
    loss_png = out_png.with_name(out_png.stem + "_loss.png")
    plt.savefig(loss_png, dpi=200)
    plt.close()

    # Plot ACC (kalau ada)
    if tr_acc is not None and va_acc is not None:
        plt.figure()
        plt.plot(epochs, tr_acc, label="train_acc")
        plt.plot(epochs, va_acc, label="val_acc")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.title(f"{title} (Accuracy)")
        plt.legend()
        plt.tight_layout()
        acc_png = out_png.with_name(out_png.stem + "_acc.png")
        plt.savefig(acc_png, dpi=200)
        plt.close()
        return loss_png, acc_png

    return loss_png, None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", required=True, help="D:/evan TA/New folder/256body25_25_50.txt")
    ap.add_argument("--outdir", default="plots", help="D:/evan TA/New folder")
    ap.add_argument("--title", default=None, help="kk")
    args = ap.parse_args()

    log_path = Path(args.log)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    text = log_path.read_text(encoding="utf-8", errors="ignore")
    epochs, tr_loss, va_loss, tr_acc, va_acc = parse_log(text)

    if len(epochs) == 0:
        raise SystemExit(
            "Tidak ada baris Epoch yang kebaca. Pastikan formatnya seperti:\n"
            "Epoch 001 | train_loss=... acc=... || val_loss=... acc=..."
        )

    title = args.title or log_path.stem
    out_png = outdir / f"{log_path.stem}.png"

    loss_png, acc_png = plot_curves(epochs, tr_loss, va_loss, tr_acc, va_acc, title, out_png)

    print(f"Saved: {loss_png}")
    if acc_png:
        print(f"Saved: {acc_png}")

if __name__ == "__main__":
    main()
