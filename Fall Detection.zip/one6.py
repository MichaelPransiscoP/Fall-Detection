import os
import glob
import random
import argparse
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, Subset, WeightedRandomSampler
from torch.nn.utils.rnn import pack_padded_sequence

# ============================================================
# 1. Dataset NPZ (asli)
# ============================================================

class NpzSequenceDataset(Dataset):
    """
    Membaca file NPZ:
      - key 'keypoints' shape (T, K, 3)
      - gunakan channel x,y -> (T, K*2)
      - pad / truncate ke panjang max_len
    """

    def __init__(self, files, labels, max_len=400):
        self.files = files
        self.labels = labels
        self.max_len = max_len

        if len(self.files) != len(self.labels):
            raise ValueError("files dan labels harus sama panjang.")

        # cek 1 contoh untuk dapatkan input_size
        sample = np.load(self.files[0])["keypoints"]
        T, K, C = sample.shape
        self.K = K
        self.input_size = K * 2  # x,y saja

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        path = self.files[idx]
        label = self.labels[idx]

        data = np.load(path)["keypoints"].astype(np.float32)  # (T, K, 3)

        # amankan kalau ada NaN (misal RAW)
        data = np.nan_to_num(data, nan=0.0)

        T, K, C = data.shape

        # ambil x,y -> (T, K, 2)
        data_xy = data[:, :, :2]

        # reshape ke (T, K*2)
        seq = data_xy.reshape(T, K * 2)

        # pad / truncate ke max_len
        if T >= self.max_len:
            seq = seq[:self.max_len]
            length = self.max_len
        else:
            pad = np.zeros((self.max_len - T, K * 2), dtype=np.float32)
            seq = np.vstack([seq, pad])
            length = T

        seq_tensor = torch.from_numpy(seq)                # (max_len, input_size)
        label_tensor = torch.tensor(float(label))         # 0.0 atau 1.0
        length_tensor = torch.tensor(length, dtype=torch.long)

        return seq_tensor, length_tensor, label_tensor


def collate_fn(batch):
    """
    batch: list of (seq, length, label)
    output:
      - seqs: (batch, max_len, input_size)
      - lengths: (batch,)
      - labels: (batch,)
    """
    seqs = torch.stack([b[0] for b in batch], dim=0)
    lengths = torch.stack([b[1] for b in batch], dim=0)
    labels = torch.stack([b[2] for b in batch], dim=0)
    return seqs, lengths, labels

# ============================================================
# 1b. Dataset TRAIN khusus: 20 FALL asli + 10 noise + 30 ADL
# ============================================================

class Train2030NoiseDataset(Dataset):
    """
    Dataset untuk TRAIN:
      - 20 FALL asli       (tanpa noise)
      - 30 ADL            (tanpa noise)
      - 10 FALL noise     (copy dari subset FALL, diberi noise)
    Urutan index:
      [0 .. n_fall_orig-1]          -> FALL asli
      [n_fall_orig .. n_fall_orig+n_adl-1] -> ADL
      [sisanya]                     -> FALL noise
    """

    def __init__(self, base_dataset, fall_orig_indices, adl_indices,
                 fall_noise_indices, noise_sigma=3.0):
        self.base = base_dataset
        self.fall_orig = list(fall_orig_indices)
        self.adl = list(adl_indices)
        self.fall_noise = list(fall_noise_indices)
        self.noise_sigma = noise_sigma

        self.n_fall_orig = len(self.fall_orig)
        self.n_adl = len(self.adl)
        self.n_fall_noise = len(self.fall_noise)

    def __len__(self):
        return self.n_fall_orig + self.n_adl + self.n_fall_noise

    def __getitem__(self, idx):
        # 1) FALL asli (tanpa noise)
        if idx < self.n_fall_orig:
            base_idx = self.fall_orig[idx]
            seq, length, label = self.base[base_idx]
            return seq, length, label

        # 2) ADL
        elif idx < self.n_fall_orig + self.n_adl:
            j = idx - self.n_fall_orig
            base_idx = self.adl[j]
            seq, length, label = self.base[base_idx]
            return seq, length, label

        # 3) FALL noise (copy FALL + noise)
        else:
            j = idx - (self.n_fall_orig + self.n_adl)
            base_idx = self.fall_noise[j]
            seq, length, label = self.base[base_idx]  # label harus 1.0

            # kalau mau matikan noise, set noise_sigma=0 di argumen
            if self.noise_sigma > 0 and label.item() >= 0.5:
                L = int(length.item())
                if L > 0:
                    seq = seq.clone()
                    noise = torch.normal(
                        mean=0.0,
                        std=self.noise_sigma,
                        size=seq[:L].shape
                    )
                    seq[:L] += noise

            return seq, length, label

# ============================================================
# 2. Model LSTM + Dense Head (Linear -> ReLU -> Dropout -> Linear)
# ============================================================

class LSTMClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=1, dropout=0.2):
        """
        - LSTM sebagai backbone temporal
        - Dense head: Linear -> ReLU -> Dropout -> Linear
        """
        super().__init__()

        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True
        )

        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, 1)
        )

    def forward(self, x, lengths=None):
        """
        x: (batch, seq_len, input_size)
        lengths: (batch,) panjang sekuens asli sebelum padding
        """
        if lengths is not None:
            lengths_cpu = lengths.cpu()
            packed = pack_padded_sequence(
                x,
                lengths_cpu,
                batch_first=True,
                enforce_sorted=False
            )
            _, (h_n, c_n) = self.lstm(packed)
        else:
            _, (h_n, c_n) = self.lstm(x)

        # h_n: (num_layers, batch, hidden_size)
        h_last = h_n[-1]  # (batch, hidden_size)

        logits = self.head(h_last).squeeze(1)  # (batch,)
        return logits

# ============================================================
# 3. Utility: confusion matrix & metrics
# ============================================================

def update_confusion_matrix(y_true, y_prob, tp, tn, fp, fn, threshold=0.5):
    """
    Update TP, TN, FP, FN berdasarkan prediksi batch.
    y_true: tensor (B,) nilai 0/1
    y_prob: tensor (B,) probabilitas p(fall)
    """
    y_pred = (y_prob >= threshold).float()
    tp += ((y_pred == 1) & (y_true == 1)).sum().item()
    tn += ((y_pred == 0) & (y_true == 0)).sum().item()
    fp += ((y_pred == 1) & (y_true == 0)).sum().item()
    fn += ((y_pred == 0) & (y_true == 1)).sum().item()
    return tp, tn, fp, fn


def compute_from_cm(tp, tn, fp, fn):
    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total > 0 else 0.0
    sens = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    return acc, sens, spec

# ============================================================
# 4. Train + Val + Test
#    Train: 20 FALL asli + 10 noise + 30 ADL
#    Sisa (10 FALL + 10 ADL) -> val + test
# ============================================================

def train_model(args):
    # device
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    print(f"Gunakan device: {device}")

    # kumpulkan file fall dan non-fall
    fall_files = sorted(glob.glob(os.path.join(args.fall_dir, "*.npz")))
    non_files  = sorted(glob.glob(os.path.join(args.non_dir, "*.npz")))

    n_fall = len(fall_files)
    n_adl  = len(non_files)
    print(f"Jumlah file: FALL={n_fall} | ADL={n_adl}")

    # butuh minimal 30 FALL & 40 ADL supaya skema ini pas
    if n_fall < 30 or n_adl < 40:
        raise RuntimeError("Butuh minimal 30 FALL dan 40 ADL untuk skema 20+10 noise + 30 ADL train.")

    # gabungkan untuk membuat full_dataset
    all_files  = fall_files + non_files
    all_labels = [1] * n_fall + [0] * n_adl

    full_dataset = NpzSequenceDataset(all_files, all_labels, max_len=args.max_len)
    input_size = full_dataset.input_size
    N = len(full_dataset)
    print(f"Total sampel: {N} | input_size: {input_size}")

    # --------------------------------------------------------
    # Buat index FALL & ADL di full_dataset
    # FALL index = 0..(n_fall-1)
    # ADL index  = n_fall..(n_fall + n_adl - 1)
    # --------------------------------------------------------
    fall_indices = list(range(n_fall))
    adl_indices  = list(range(n_fall, n_fall + n_adl))

    rng = random.Random(42)
    rng.shuffle(fall_indices)
    rng.shuffle(adl_indices)

    # ===================== TRAIN SPLIT =======================
    # FALL:
    #  - 20 FALL asli untuk train
    #  - 10 FALL sisa untuk val+test
    n_train_fall_orig = 20
    n_fall_noise = 10  # jumlah sampel FALL noise di train

    train_fall_orig = fall_indices[:n_train_fall_orig]     # 20
    remain_fall_idx = fall_indices[n_train_fall_orig:]     # minimal 10 sisa

    # pilih 10 di antara 20 FALL train untuk dijadikan sumber noise
    fall_noise_indices = train_fall_orig[:n_fall_noise]    # 10

    # ADL:
    #  - 30 ADL untuk train
    #  - 10 ADL untuk val+test
    n_train_adl = 30
    train_adl_idx = adl_indices[:n_train_adl]              # 30
    remain_adl_idx = adl_indices[n_train_adl:]             # 10

    # sisa 10 FALL + 10 ADL -> val+test
    remaining_indices = remain_fall_idx + remain_adl_idx   # 20 index
    rng.shuffle(remaining_indices)

    n_remain = len(remaining_indices)      # 20
    n_val = n_remain // 2                  # 10
    val_indices  = remaining_indices[:n_val]
    test_indices = remaining_indices[n_val:]

    print(f"Train FALL original : {len(train_fall_orig)}")
    print(f"Train FALL noise    : {len(fall_noise_indices)}")
    print(f"Train ADL           : {len(train_adl_idx)}")
    print(f"Val indices         : {len(val_indices)}")
    print(f"Test indices        : {len(test_indices)}")

    # Dataset:
    train_ds = Train2030NoiseDataset(
        base_dataset=full_dataset,
        fall_orig_indices=train_fall_orig,
        adl_indices=train_adl_idx,
        fall_noise_indices=fall_noise_indices,
        noise_sigma=args.noise_sigma
    )

    val_ds  = Subset(full_dataset, val_indices)
    test_ds = Subset(full_dataset, test_indices)

    # ===================== WeightedRandomSampler =====================
    # Label train (urutan harus sama dengan urutan Train2030NoiseDataset)
    train_labels = (
        [1] * len(train_fall_orig) +      # 20 FALL asli
        [0] * len(train_adl_idx) +        # 30 ADL
        [1] * len(fall_noise_indices)     # 10 FALL noise
    )
    train_labels = np.array(train_labels)
    class_sample_count = np.bincount(train_labels)  # [30, 30]
    class_weights = 1.0 / class_sample_count

    sample_weights = np.array([class_weights[l] for l in train_labels])
    sample_weights = torch.DoubleTensor(sample_weights)

    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True
    )

    # ===================== DataLoader =====================
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        sampler=sampler,
        collate_fn=collate_fn
    )

    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn
    )

    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn
    )

    # ===================== Model & Optimizer =====================
    model = LSTMClassifier(
        input_size=input_size,
        hidden_size=args.hidden,
        num_layers=args.num_layers,
        dropout=args.dropout
    ).to(device)

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    # =======================================================
    # TRAINING LOOP
    # =======================================================
    for epoch in range(1, args.epochs + 1):
        # ----------------- TRAIN -----------------
        model.train()
        train_loss = 0.0
        n_batch_train = 0

        train_tp = train_tn = train_fp = train_fn = 0

        for seqs, lengths, labels_batch in train_loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels_batch = labels_batch.to(device)

            optimizer.zero_grad()

            logits = model(seqs, lengths)
            loss = criterion(logits, labels_batch)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

            train_loss += loss.item()
            n_batch_train += 1

            probs = torch.sigmoid(logits).detach().cpu()
            y_true = labels_batch.detach().cpu()

            train_tp, train_tn, train_fp, train_fn = update_confusion_matrix(
                y_true, probs, train_tp, train_tn, train_fp, train_fn
            )

        train_loss /= max(n_batch_train, 1)
        train_acc, train_sens, train_spec = compute_from_cm(
            train_tp, train_tn, train_fp, train_fn
        )

        # ----------------- VALIDATION -----------------
        model.eval()
        val_loss = 0.0
        n_batch_val = 0

        val_tp = val_tn = val_fp = val_fn = 0

        with torch.no_grad():
            for seqs, lengths, labels_batch in val_loader:
                seqs = seqs.to(device)
                lengths = lengths.to(device)
                labels_batch = labels_batch.to(device)

                logits = model(seqs, lengths)
                loss = criterion(logits, labels_batch)

                val_loss += loss.item()
                n_batch_val += 1

                probs = torch.sigmoid(logits).cpu()
                y_true = labels_batch.cpu()

                val_tp, val_tn, val_fp, val_fn = update_confusion_matrix(
                    y_true, probs, val_tp, val_tn, val_fp, val_fn
                )

        val_loss /= max(n_batch_val, 1)
        val_acc, val_sens, val_spec = compute_from_cm(
            val_tp, val_tn, val_fp, val_fn
        )

        # ----------------- PRINT HASIL EPOCH -----------------
        print(
            f"Epoch {epoch:03d} | "
            f"train_loss={train_loss:.4f} acc={train_acc:.4f} "
            f"sens={train_sens:.4f} spec={train_spec:.4f} || "
            f"val_loss={val_loss:.4f} acc={val_acc:.4f} "
            f"sens={val_sens:.4f} spec={val_spec:.4f}"
        )
        print(f"CM train: TP={train_tp} TN={train_tn} FP={train_fp} FN={train_fn}")
        print(f"CM val  : TP={val_tp} TN={val_tn} FP={val_fp} FN={val_fn}")
        print("-" * 60)

    # simpan model kalau diminta
    if args.out_model:
        os.makedirs(os.path.dirname(args.out_model), exist_ok=True)
        torch.save(model.state_dict(), args.out_model)
        print(f"Model disimpan ke: {args.out_model}")

    # =======================================================
    # TESTING (split test)
    # =======================================================
    run_testing(model, test_loader, device, criterion)

    # =======================================================
    # TESTING 1–1 PER VIDEO (split test)
    # =======================================================
    run_testing_one_by_one(model, test_ds, full_dataset, device)

# ============================================================
# 5. Testing biasa (split test)
# ============================================================

def run_testing(model, test_loader, device, criterion):
    print("\n==================== TESTING (SPLIT TEST) ====================")

    model.eval()
    test_loss = 0.0
    n_batch_test = 0

    test_tp = test_tn = test_fp = test_fn = 0
    total_samples = 0

    with torch.no_grad():
        for seqs, lengths, labels_batch in test_loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels_batch = labels_batch.to(device)

            logits = model(seqs, lengths)
            loss = criterion(logits, labels_batch)

            test_loss += loss.item()
            n_batch_test += 1
            total_samples += labels_batch.size(0)

            probs = torch.sigmoid(logits).cpu()
            y_true = labels_batch.cpu()

            test_tp, test_tn, test_fp, test_fn = update_confusion_matrix(
                y_true, probs, test_tp, test_tn, test_fp, test_fn
            )

    test_loss /= max(n_batch_test, 1)
    test_acc, test_sens, test_spec = compute_from_cm(
        test_tp, test_tn, test_fp, test_fn
    )

    print(
        f"TEST (split) | "
        f"samples={total_samples} "
        f"loss={test_loss:.4f} acc={test_acc:.4f} "
        f"sens={test_sens:.4f} spec={test_spec:.4f}"
    )
    print(f"CM test: TP={test_tp} TN={test_tn} FP={test_fp} FN={test_fn}")
    print("=============================================================\n")

# ============================================================
# 6. Testing 1–1 per video (split test)
# ============================================================

def run_testing_one_by_one(model, test_subset, full_dataset, device, threshold=0.5):
    """
    Testing 1–1: setiap sampel (1 video) diuji satu per satu.
    """
    print("\n==================== TESTING 1–1 PER VIDEO (split test) ====================")
    model.eval()

    fall_total = 0
    fall_correct = 0

    adl_total = 0
    adl_correct = 0

    # indices real dari Subset
    indices = getattr(test_subset, "indices", list(range(len(test_subset))))

    with torch.no_grad():
        for local_idx, real_idx in enumerate(indices):
            seq, length, label = test_subset[local_idx]

            seq = seq.unsqueeze(0).to(device)
            length = length.unsqueeze(0).to(device)

            if isinstance(label, torch.Tensor):
                label_val = int(label.item())
            else:
                label_val = int(label)

            logits = model(seq, length)
            prob = torch.sigmoid(logits)[0].item()
            pred = 1 if prob >= threshold else 0

            # ambil nama file asli dari full_dataset
            fname = None
            if hasattr(full_dataset, "files"):
                try:
                    fname = os.path.basename(full_dataset.files[real_idx])
                except Exception:
                    fname = f"idx{real_idx}"
            else:
                fname = f"sample_{local_idx}"

            status = "Benar" if pred == label_val else "Salah"
            label_str = "FALL" if label_val == 1 else "ADL"
            pred_str = "FALL" if pred == 1 else "ADL"

            print(f"{fname:40s} | label={label_str:4s} pred={pred_str:4s} prob={prob:.4f} | {status}")

            if label_val == 1:
                fall_total += 1
                if pred == 1:
                    fall_correct += 1
            else:
                adl_total += 1
                if pred == 0:
                    adl_correct += 1

    fall_acc = fall_correct / fall_total if fall_total > 0 else 0.0
    adl_acc  = adl_correct  / adl_total  if adl_total  > 0 else 0.0
    total_acc = (fall_correct + adl_correct) / (fall_total + adl_total) if (fall_total + adl_total) > 0 else 0.0

    print("\n-------------------- RINGKASAN 1–1 (split test) --------------------")
    print(f"FALL-only | benar {fall_correct} / {fall_total}  -> acc={fall_acc:.4f}")
    print(f"ADL-only  | benar {adl_correct} / {adl_total}   -> acc={adl_acc:.4f}")
    print(f"TOTAL     | benar {fall_correct + adl_correct} / {fall_total + adl_total} -> acc={total_acc:.4f}")
    print("======================================================\n")

# ============================================================
# 7. Argparse
# ============================================================

def main():
    p = argparse.ArgumentParser(description="Train LSTM Fall Detection (20 FALL + 10 noise + 30 ADL train).")
    p.add_argument("--fall_dir", type=str, required=True, help="Folder NPZ kelas fall.")
    p.add_argument("--non_dir", type=str, required=True, help="Folder NPZ kelas non-fall.")
    p.add_argument("--hidden", type=int, default=256, help="Hidden size LSTM.")
    p.add_argument("--num_layers", type=int, default=1, help="Jumlah layer LSTM.")
    p.add_argument("--dropout", type=float, default=0.2, help="Dropout pada dense head.")
    p.add_argument("--epochs", type=int, default=300, help="Jumlah epoch.")
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--max_len", type=int, default=400, help="Panjang sekuens tetap (pad/truncate).")
    p.add_argument("--out_model", type=str, default=None, help="Path simpan model .pth")
    p.add_argument("--cpu", action="store_true", help="Paksa pakai CPU.")
    p.add_argument("--noise_sigma", type=float, default=3.0,
                   help="Std dev noise Gaussian untuk 10 sampel FALL noise di train (0 = tanpa noise).")

    args = p.parse_args()
    train_model(args)


if __name__ == "__main__":
    main()
