import os
import glob
import random
import argparse
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, Subset
from torch.nn.utils.rnn import pack_padded_sequence

# ============================================================
# 1. Dataset NPZ
# ============================================================

class NpzSequenceDataset(Dataset):
    """
    Membaca file NPZ:
      - key 'keypoints' shape (T, K, 3)
      - gunakan channel x,y -> (T, K*2)
      - pad / truncate ke panjang max_len
    """

    def __init__(self, files, labels, max_len=400):
        self.files = files
        self.labels = labels
        self.max_len = max_len

        if len(self.files) != len(self.labels):
            raise ValueError("files dan labels harus sama panjang.")

        # cek 1 contoh untuk dapatkan input_size
        sample = np.load(self.files[0])["keypoints"]
        T, K, C = sample.shape
        self.K = K
        self.input_size = K * 2  # x,y saja

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        path = self.files[idx]
        label = self.labels[idx]

        data = np.load(path)["keypoints"].astype(np.float32)  # (T, K, 3)

        # kalau ada NaN (misal dari RAW), aman-kan:
        data = np.nan_to_num(data, nan=0.0)

        T, K, C = data.shape

        # ambil x,y -> (T, K, 2)
        data_xy = data[:, :, :2]

        # reshape ke (T, K*2)
        seq = data_xy.reshape(T, K * 2)

        # pad / truncate ke max_len
        if T >= self.max_len:
            seq = seq[:self.max_len]
            length = self.max_len
        else:
            pad = np.zeros((self.max_len - T, K * 2), dtype=np.float32)
            seq = np.vstack([seq, pad])
            length = T

        seq_tensor = torch.from_numpy(seq)                # (max_len, input_size)
        label_tensor = torch.tensor(float(label))         # 0.0 atau 1.0
        length_tensor = torch.tensor(length, dtype=torch.long)

        return seq_tensor, length_tensor, label_tensor


def collate_fn(batch):
    """
    batch: list of (seq, length, label)
    output:
      - seqs: (batch, max_len, input_size)
      - lengths: (batch,)
      - labels: (batch,)
    """
    seqs = torch.stack([b[0] for b in batch], dim=0)
    lengths = torch.stack([b[1] for b in batch], dim=0)
    labels = torch.stack([b[2] for b in batch], dim=0)
    return seqs, lengths, labels

# ============================================================
# 2. Model LSTM + Dense Head (Linear -> ReLU -> Dropout -> Linear)
# ============================================================

class LSTMClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=1, dropout=0.2):
        """
        - LSTM sebagai backbone temporal
        - Dense head: Linear -> ReLU -> Dropout -> Linear
        """
        super().__init__()

        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True
        )

        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, 1)
        )

    def forward(self, x, lengths=None):
        """
        x: (batch, seq_len, input_size)
        lengths: (batch,) panjang sekuens asli sebelum padding
        """
        if lengths is not None:
            lengths_cpu = lengths.cpu()
            packed = pack_padded_sequence(
                x,
                lengths_cpu,
                batch_first=True,
                enforce_sorted=False
            )
            _, (h_n, c_n) = self.lstm(packed)
        else:
            _, (h_n, c_n) = self.lstm(x)

        # h_n: (num_layers, batch, hidden_size)
        h_last = h_n[-1]  # (batch, hidden_size)

        logits = self.head(h_last).squeeze(1)  # (batch,)
        return logits

# ============================================================
# 3. Utility: confusion matrix & metrics
# ============================================================

def update_confusion_matrix(y_true, y_prob, tp, tn, fp, fn, threshold=0.5):
    """
    Update TP, TN, FP, FN berdasarkan prediksi batch.
    y_true: tensor (B,) nilai 0/1
    y_prob: tensor (B,) probabilitas p(fall)
    """
    y_pred = (y_prob >= threshold).float()
    tp += ((y_pred == 1) & (y_true == 1)).sum().item()
    tn += ((y_pred == 0) & (y_true == 0)).sum().item()
    fp += ((y_pred == 1) & (y_true == 0)).sum().item()
    fn += ((y_pred == 0) & (y_true == 1)).sum().item()
    return tp, tn, fp, fn


def compute_from_cm(tp, tn, fp, fn):
    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total > 0 else 0.0
    sens = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    return acc, sens, spec

# ============================================================
# 4. Train + Val + Test dengan split khusus:
#    - Total 70 video
#    - Train 50 video: 25 FALL + 25 ADL
#    - Sisa 20 video → val + test (dibagi 1/2: 10 val, 10 test)
#    + EARLY STOPPING (patience)
# ============================================================

def train_model(args):
    # device
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    print(f"Gunakan device: {device}")

    # kumpulkan file fall dan non-fall
    fall_files = sorted(glob.glob(os.path.join(args.fall_dir, "*.npz")))
    non_files  = sorted(glob.glob(os.path.join(args.non_dir, "*.npz")))

    n_fall = len(fall_files)
    n_adl  = len(non_files)
    print(f"Jumlah file: FALL={n_fall} | ADL={n_adl}")

    if n_fall < 25 or n_adl < 25:
        raise RuntimeError("Butuh minimal 25 FALL dan 25 NON-FALL untuk train.")

    # gabungkan untuk membuat full_dataset
    all_files  = fall_files + non_files
    all_labels = [1] * n_fall + [0] * n_adl

    full_dataset = NpzSequenceDataset(all_files, all_labels, max_len=args.max_len)
    input_size = full_dataset.input_size
    N = len(full_dataset)
    print(f"Total sampel: {N} | input_size: {input_size}")

    # --------------------------------------------------------
    # Buat index FALL & ADL di full_dataset
    # FALL index = 0..(n_fall-1)
    # ADL index  = n_fall..(n_fall + n_adl - 1)
    # --------------------------------------------------------
    fall_indices = list(range(n_fall))
    adl_indices  = list(range(n_fall, n_fall + n_adl))

    rng = random.Random(42)
    rng.shuffle(fall_indices)
    rng.shuffle(adl_indices)

    # Train: 25 FALL + 25 ADL
    n_train_fall = 25
    n_train_adl  = 25

    train_fall_idx   = fall_indices[:n_train_fall]
    remain_fall_idx  = fall_indices[n_train_fall:]

    train_adl_idx    = adl_indices[:n_train_adl]
    remain_adl_idx   = adl_indices[n_train_adl:]

    train_indices = train_fall_idx + train_adl_idx

    # Sisa: 5 FALL + 15 ADL = 20 → val + test
    remaining_indices = remain_fall_idx + remain_adl_idx
    rng.shuffle(remaining_indices)

    # Bagi dua: 1/2 val, 1/2 test (10–10)
    n_remain = len(remaining_indices)
    n_val = n_remain // 2
    val_indices  = remaining_indices[:n_val]
    test_indices = remaining_indices[n_val:]

    print(f"Split index: train={len(train_indices)} | val={len(val_indices)} | test={len(test_indices)}")

    train_ds = Subset(full_dataset, train_indices)
    val_ds   = Subset(full_dataset, val_indices)
    test_ds  = Subset(full_dataset, test_indices)

    # DataLoader
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=collate_fn
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn
    )

    # model
    model = LSTMClassifier(
        input_size=input_size,
        hidden_size=args.hidden,
        num_layers=args.num_layers,
        dropout=args.dropout
    ).to(device)

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    # EARLY STOPPING
    best_val_loss = float("inf")
    best_state = None
    best_epoch = 0
    epochs_no_improve = 0

    # =======================================================
    # TRAINING LOOP
    # =======================================================
    for epoch in range(1, args.epochs + 1):
        # ----------------- TRAIN -----------------
        model.train()
        train_loss = 0.0
        n_batch_train = 0

        train_tp = train_tn = train_fp = train_fn = 0

        for seqs, lengths, labels_batch in train_loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels_batch = labels_batch.to(device)

            optimizer.zero_grad()

            logits = model(seqs, lengths)
            loss = criterion(logits, labels_batch)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

            train_loss += loss.item()
            n_batch_train += 1

            probs = torch.sigmoid(logits).detach().cpu()
            y_true = labels_batch.detach().cpu()

            train_tp, train_tn, train_fp, train_fn = update_confusion_matrix(
                y_true, probs, train_tp, train_tn, train_fp, train_fn
            )

        train_loss /= n_batch_train
        train_acc, train_sens, train_spec = compute_from_cm(
            train_tp, train_tn, train_fp, train_fn
        )

        # ----------------- VALIDATION -----------------
        model.eval()
        val_loss = 0.0
        n_batch_val = 0

        val_tp = val_tn = val_fp = val_fn = 0

        with torch.no_grad():
            for seqs, lengths, labels_batch in val_loader:
                seqs = seqs.to(device)
                lengths = lengths.to(device)
                labels_batch = labels_batch.to(device)

                logits = model(seqs, lengths)
                loss = criterion(logits, labels_batch)

                val_loss += loss.item()
                n_batch_val += 1

                probs = torch.sigmoid(logits).cpu()
                y_true = labels_batch.cpu()

                val_tp, val_tn, val_fp, val_fn = update_confusion_matrix(
                    y_true, probs, val_tp, val_tn, val_fp, val_fn
                )

        val_loss /= n_batch_val
        val_acc, val_sens, val_spec = compute_from_cm(
            val_tp, val_tn, val_fp, val_fn
        )

        # ----------------- PRINT HASIL EPOCH -----------------
        print(
            f"Epoch {epoch:03d} | "
            f"train_loss={train_loss:.4f} acc={train_acc:.4f} "
            f"sens={train_sens:.4f} spec={train_spec:.4f} || "
            f"val_loss={val_loss:.4f} acc={val_acc:.4f} "
            f"sens={val_sens:.4f} spec={val_spec:.4f}"
        )
        print(f"CM train: TP={train_tp} TN={train_tn} FP={train_fp} FN={train_fn}")
        print(f"CM val  : TP={val_tp} TN={val_tn} FP={val_fp} FN={val_fn}")
        print("-" * 60)

        # ----------------- EARLY STOPPING -----------------
        if val_loss < best_val_loss - 1e-6:
            best_val_loss = val_loss
            best_state = model.state_dict()
            best_epoch = epoch
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= args.patience:
                print(f"Early stopping di epoch {epoch} (best epoch = {best_epoch}, val_loss={best_val_loss:.4f})")
                break

    # pakai model terbaik (val_loss paling kecil)
    if best_state is not None:
        model.load_state_dict(best_state)
        print(f"Model di-restore ke epoch terbaik: {best_epoch} (val_loss={best_val_loss:.4f})")

    # simpan model
    if args.out_model:
        os.makedirs(os.path.dirname(args.out_model), exist_ok=True)
        torch.save(model.state_dict(), args.out_model)
        print(f"Model disimpan ke: {args.out_model}")

    # =======================================================
    # TESTING SPLIT (10 video sisa, tapi di sini 10 dari 20)
    # =======================================================
    run_testing(model, test_loader, device, criterion)

    # =======================================================
    # TESTING 1–1 PER VIDEO
    # =======================================================
    run_testing_one_by_one(model, test_ds, full_dataset, device)


# ============================================================
# 5. Testing biasa (split)
# ============================================================

def run_testing(model, test_loader, device, criterion):
    print("\n==================== TESTING (SPLIT) ====================")

    model.eval()
    test_loss = 0.0
    n_batch_test = 0

    test_tp = test_tn = test_fp = test_fn = 0
    total_samples = 0

    with torch.no_grad():
        for seqs, lengths, labels_batch in test_loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels_batch = labels_batch.to(device)

            logits = model(seqs, lengths)
            loss = criterion(logits, labels_batch)

            test_loss += loss.item()
            n_batch_test += 1
            total_samples += labels_batch.size(0)

            probs = torch.sigmoid(logits).cpu()
            y_true = labels_batch.cpu()

            test_tp, test_tn, test_fp, test_fn = update_confusion_matrix(
                y_true, probs, test_tp, test_tn, test_fp, test_fn
            )

    test_loss /= n_batch_test
    test_acc, test_sens, test_spec = compute_from_cm(
        test_tp, test_tn, test_fp, test_fn
    )

    print(
        f"TEST | "
        f"samples={total_samples} "
        f"loss={test_loss:.4f} acc={test_acc:.4f} "
        f"sens={test_sens:.4f} spec={test_spec:.4f}"
    )
    print(f"CM test: TP={test_tp} TN={test_tn} FP={test_fp} FN={test_fn}")
    print("=============================================================\n")


# ============================================================
# 6. Testing 1–1 per video
# ============================================================

def run_testing_one_by_one(model, test_subset, full_dataset, device, threshold=0.5):
    """
    Testing 1–1: setiap sampel (1 video) diuji satu per satu.
    """
    print("\n==================== TESTING 1–1 PER VIDEO ====================")
    model.eval()

    fall_total = 0
    fall_correct = 0

    adl_total = 0
    adl_correct = 0

    # indices real dari Subset
    indices = getattr(test_subset, "indices", list(range(len(test_subset))))

    with torch.no_grad():
        for local_idx, real_idx in enumerate(indices):
            # ambil data lewat Subset
            seq, length, label = test_subset[local_idx]

            seq = seq.unsqueeze(0).to(device)
            length = length.unsqueeze(0).to(device)

            if isinstance(label, torch.Tensor):
                label_val = int(label.item())
            else:
                label_val = int(label)

            logits = model(seq, length)
            prob = torch.sigmoid(logits)[0].item()
            pred = 1 if prob >= threshold else 0

            # ambil nama file asli dari full_dataset
            fname = None
            if hasattr(full_dataset, "files"):
                try:
                    fname = os.path.basename(full_dataset.files[real_idx])
                except Exception:
                    fname = f"idx{real_idx}"
            else:
                fname = f"sample_{local_idx}"

            status = "Benar" if pred == label_val else "Salah"
            label_str = "FALL" if label_val == 1 else "ADL"
            pred_str = "FALL" if pred == 1 else "ADL"

            print(f"{fname:40s} | label={label_str:4s} pred={pred_str:4s} prob={prob:.4f} | {status}")

            if label_val == 1:
                fall_total += 1
                if pred == 1:
                    fall_correct += 1
            else:
                adl_total += 1
                if pred == 0:
                    adl_correct += 1

    fall_acc = fall_correct / fall_total if fall_total > 0 else 0.0
    adl_acc  = adl_correct  / adl_total  if adl_total  > 0 else 0.0
    total_acc = (fall_correct + adl_correct) / (fall_total + adl_total) if (fall_total + adl_total) > 0 else 0.0

    print("\n-------------------- RINGKASAN 1–1 --------------------")
    print(f"FALL-only | benar {fall_correct} / {fall_total}  -> acc={fall_acc:.4f}")
    print(f"ADL-only  | benar {adl_correct} / {adl_total}   -> acc={adl_acc:.4f}")
    print(f"TOTAL     | benar {fall_correct + adl_correct} / {fall_total + adl_total} -> acc={total_acc:.4f}")
    print("======================================================\n")


# ============================================================
# 7. Argparse
# ============================================================

def main():
    p = argparse.ArgumentParser(description="Train LSTM Fall Detection dengan split 25 FALL + 25 ADL (train) + early stopping.")
    p.add_argument("--fall_dir", type=str, required=True, help="Folder NPZ kelas fall.")
    p.add_argument("--non_dir", type=str, required=True, help="Folder NPZ kelas non-fall.")
    p.add_argument("--hidden", type=int, default=256, help="Hidden size LSTM.")
    p.add_argument("--num_layers", type=int, default=1, help="Jumlah layer LSTM.")
    p.add_argument("--dropout", type=float, default=0.2, help="Dropout pada dense head.")
    p.add_argument("--epochs", type=int, default=300, help="Maksimal epoch.")
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--max_len", type=int, default=400, help="Panjang sekuens tetap (pad/truncate).")
    p.add_argument("--out_model", type=str, default=None, help="Path simpan model .pth")
    p.add_argument("--patience", type=int, default=0, help="Jumlah epoch tanpa perbaikan val_loss sebelum stop.")
    p.add_argument("--cpu", action="store_true", help="Paksa pakai CPU.")

    args = p.parse_args()
    train_model(args)


if __name__ == "__main__":
    main()
