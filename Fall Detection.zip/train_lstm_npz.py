import os
import argparse
import glob
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from torch.nn.utils.rnn import pack_padded_sequence  # untuk pack_padded_sequence

# ======================================================================
# 1. Dataset dari NPZ
# ======================================================================

class NpzSequenceDataset(Dataset):
    """
    Membaca file NPZ:
      - key 'keypoints' shape (T, K, 3)
      - gunakan channel x,y -> (T, K*2)
      - pad / truncate ke panjang max_len
    """
    def __init__(self, files, labels, max_len=200):
        self.files = files
        self.labels = labels  # 1 = fall, 0 = non-fall
        self.max_len = max_len

        if len(self.files) != len(self.labels):
            raise ValueError("files dan labels harus sama panjang.")

        # cek 1 contoh untuk dapatkan input_size
        sample = np.load(self.files[0])["keypoints"]
        T, K, C = sample.shape
        self.K = K
        self.input_size = K * 2  # x,y saja

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        path = self.files[idx]
        label = self.labels[idx]

        data = np.load(path)["keypoints"].astype(np.float32)  # (T, K, 3)
        T, K, C = data.shape

        # ambil x,y -> (T, K, 2)
        data_xy = data[:, :, :2]

        # reshape ke (T, K*2)
        seq = data_xy.reshape(T, K * 2)

        # pad / truncate ke max_len
        if T >= self.max_len:
            seq = seq[:self.max_len]
            length = self.max_len
        else:
            pad = np.zeros((self.max_len - T, K * 2), dtype=np.float32)
            seq = np.vstack([seq, pad])
            length = T

        seq_tensor = torch.from_numpy(seq)                # (max_len, input_size)
        label_tensor = torch.tensor(float(label))         # 0.0 atau 1.0
        length_tensor = torch.tensor(length, dtype=torch.long)

        return seq_tensor, length_tensor, label_tensor


def collate_fn(batch):
    """
    batch: list of (seq, length, label)
    output:
      - seqs: (batch, max_len, input_size)
      - lengths: (batch,)
      - labels: (batch,)
    """
    seqs = torch.stack([b[0] for b in batch], dim=0)
    lengths = torch.stack([b[1] for b in batch], dim=0)
    labels = torch.stack([b[2] for b in batch], dim=0)
    return seqs, lengths, labels

# ======================================================================
# 2. Model LSTM + Dense Head (Linear -> ReLU -> Dropout -> Linear)
# ======================================================================

class LSTMClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=1, dropout=0.2):
        """
        - LSTM sebagai backbone temporal
        - Dense head: Linear -> ReLU -> Dropout -> Linear
        - Dropout diterapkan di dense head (bukan di LSTM langsung)
        """
        super().__init__()

        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True
        )

        # Dense head: Linear-ReLU-Dropout-Linear
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, 1)
        )

    def forward(self, x, lengths=None):
        """
        x: (batch, seq_len, input_size)
        lengths: (batch,) panjang sekuens asli sebelum padding

        Menggunakan pack_padded_sequence agar LSTM mengabaikan padding.
        """
        if lengths is not None:
            lengths_cpu = lengths.cpu()
            packed = pack_padded_sequence(
                x,
                lengths_cpu,
                batch_first=True,
                enforce_sorted=False  # tidak perlu sort manual
            )
            _, (h_n, c_n) = self.lstm(packed)
        else:
            _, (h_n, c_n) = self.lstm(x)

        # h_n: (num_layers, batch, hidden_size)
        h_last = h_n[-1]  # (batch, hidden_size)

        # dense head
        logits = self.head(h_last).squeeze(1)  # (batch,)

        return logits

# ======================================================================
# 3. Utility: confusion matrix & metrics
# ======================================================================

def update_confusion_matrix(y_true, y_prob, tp, tn, fp, fn, threshold=0.5):
    """
    Update TP, TN, FP, FN berdasarkan prediksi batch.
    y_true: tensor (B,) nilai 0/1
    y_prob: tensor (B,) probabilitas p(fall)
    """
    y_pred = (y_prob >= threshold).float()
    tp += ((y_pred == 1) & (y_true == 1)).sum().item()
    tn += ((y_pred == 0) & (y_true == 0)).sum().item()
    fp += ((y_pred == 1) & (y_true == 0)).sum().item()
    fn += ((y_pred == 0) & (y_true == 1)).sum().item()
    return tp, tn, fp, fn


def compute_from_cm(tp, tn, fp, fn):
    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total > 0 else 0.0
    sens = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    return acc, sens, spec

# ======================================================================
# 4. Utility: load file list dari folder fall / non
# ======================================================================

def load_file_lists(fall_dir, non_dir):
    fall_files = sorted(glob.glob(os.path.join(fall_dir, "*.npz")))
    non_files = sorted(glob.glob(os.path.join(non_dir, "*.npz")))

    files = fall_files + non_files
    labels = [1] * len(fall_files) + [0] * len(non_files)

    if len(files) == 0:
        raise RuntimeError("Tidak menemukan file NPZ di fall_dir / non_dir.")

    return files, labels

# ======================================================================
# 5. Train + Val + Test loop (split otomatis 70/20/10)
# ======================================================================

def train_model(args):
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    print(f"Gunakan device: {device}")

    files, labels = load_file_lists(args.fall_dir, args.non_dir)

    # buat Dataset penuh
    full_dataset = NpzSequenceDataset(files, labels, max_len=args.max_len)
    input_size = full_dataset.input_size
    N = len(full_dataset)
    print(f"Total sampel: {N} | input_size: {input_size}")

    # split 70% train, 20% val, 10% test
    test_size = max(1, int(0.1 * N))
    val_size = max(1, int(0.2 * N))
    train_size = N - val_size - test_size
    if train_size <= 0:
        raise RuntimeError("Dataset terlalu kecil untuk split 70/20/10.")

    train_ds, val_ds, test_ds = random_split(
        full_dataset,
        [train_size, val_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )

    print(f"Split: train={len(train_ds)} | val={len(val_ds)} | test={len(test_ds)}")

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=collate_fn
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        collate_fn=collate_fn
    )

    # model
    model = LSTMClassifier(
        input_size=input_size,
        hidden_size=args.hidden,
        num_layers=args.num_layers,
        dropout=args.dropout
    ).to(device)

    # Binary cross entropy with logits (sesuai klasifikasi biner)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    # ============================ TRAINING LOOP ===========================
    for epoch in range(1, args.epochs + 1):
        # ----------------- TRAIN -----------------
        model.train()
        train_loss = 0.0
        n_batch_train = 0

        # confusion matrix total train
        train_tp = train_tn = train_fp = train_fn = 0

        for seqs, lengths, labels_batch in train_loader:
            seqs = seqs.to(device)               # (B, L, input_size)
            lengths = lengths.to(device)         # (B,)
            labels_batch = labels_batch.to(device)  # (B,)

            optimizer.zero_grad()

            logits = model(seqs, lengths)        # (B,)
            loss = criterion(logits, labels_batch)

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

            train_loss += loss.item()
            n_batch_train += 1

            # hitung confusion matrix batch
            probs = torch.sigmoid(logits).detach().cpu()
            y_true = labels_batch.detach().cpu()

            train_tp, train_tn, train_fp, train_fn = update_confusion_matrix(
                y_true, probs, train_tp, train_tn, train_fp, train_fn
            )

        train_loss /= n_batch_train
        train_acc, train_sens, train_spec = compute_from_cm(
            train_tp, train_tn, train_fp, train_fn
        )

        # ----------------- VALIDATION -----------------
        model.eval()
        val_loss = 0.0
        n_batch_val = 0

        # confusion matrix total val
        val_tp = val_tn = val_fp = val_fn = 0

        with torch.no_grad():
            for seqs, lengths, labels_batch in val_loader:
                seqs = seqs.to(device)
                lengths = lengths.to(device)
                labels_batch = labels_batch.to(device)

                logits = model(seqs, lengths)
                loss = criterion(logits, labels_batch)

                val_loss += loss.item()
                n_batch_val += 1

                probs = torch.sigmoid(logits).cpu()
                y_true = labels_batch.cpu()

                val_tp, val_tn, val_fp, val_fn = update_confusion_matrix(
                    y_true, probs, val_tp, val_tn, val_fp, val_fn
                )

        val_loss /= n_batch_val
        val_acc, val_sens, val_spec = compute_from_cm(
            val_tp, val_tn, val_fp, val_fn
        )

        # ----------------- PRINT HASIL EPOCH -----------------
        print(
            f"Epoch {epoch:03d} | "
            f"train_loss={train_loss:.4f} acc={train_acc:.4f} "
            f"sens={train_sens:.4f} spec={train_spec:.4f} || "
            f"val_loss={val_loss:.4f} acc={val_acc:.4f} "
            f"sens={val_sens:.4f} spec={val_spec:.4f}"
        )
        print(f"CM train: TP={train_tp} TN={train_tn} FP={train_fp} FN={train_fn}")
        print(f"CM val  : TP={val_tp} TN={val_tn} FP={val_fp} FN={val_fn}")
        print("-" * 60)

    # simpan model
    if args.out_model:
        os.makedirs(os.path.dirname(args.out_model), exist_ok=True)
        torch.save(model.state_dict(), args.out_model)
        print(f"Model disimpan ke: {args.out_model}")

    # ============================ TESTING (DARI SPLIT) ============================
    run_testing(model, test_loader, device, criterion)


# ======================================================================
# 6. Testing dari test_loader
# ======================================================================

def run_testing(model, test_loader, device, criterion):
    print("\n==================== TESTING (SPLIT 10%) ====================")

    model.eval()
    test_loss = 0.0
    n_batch_test = 0

    test_tp = test_tn = test_fp = test_fn = 0
    total_samples = 0

    with torch.no_grad():
        for seqs, lengths, labels_batch in test_loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels_batch = labels_batch.to(device)

            logits = model(seqs, lengths)
            loss = criterion(logits, labels_batch)

            test_loss += loss.item()
            n_batch_test += 1
            total_samples += labels_batch.size(0)

            probs = torch.sigmoid(logits).cpu()
            y_true = labels_batch.cpu()

            test_tp, test_tn, test_fp, test_fn = update_confusion_matrix(
                y_true, probs, test_tp, test_tn, test_fp, test_fn
            )

    test_loss /= n_batch_test
    test_acc, test_sens, test_spec = compute_from_cm(
        test_tp, test_tn, test_fp, test_fn
    )

    print(
        f"TEST | "
        f"samples={total_samples} "
        f"loss={test_loss:.4f} acc={test_acc:.4f} "
        f"sens={test_sens:.4f} spec={test_spec:.4f}"
    )
    print(f"CM test: TP={test_tp} TN={test_tn} FP={test_fp} FN={test_fn}")
    print("=============================================================\n")

# ======================================================================
# 7. Argparse
# ======================================================================

def main():
    parser = argparse.ArgumentParser(description="Train LSTM Fall Detection dari NPZ (OpenPose).")

    parser.add_argument("--fall_dir", type=str, required=True,
                        help="Folder NPZ untuk kelas fall.")
    parser.add_argument("--non_dir", type=str, required=True,
                        help="Folder NPZ untuk kelas non-fall.")
    parser.add_argument("--hidden", type=int, default=256,
                        help="Jumlah hidden units di LSTM.")
    parser.add_argument("--num_layers", type=int, default=1,
                        help="Jumlah layer LSTM.")
    parser.add_argument("--dropout", type=float, default=0.2,
                        help="Dropout pada dense head (sesuai konfigurasi TA).")
    parser.add_argument("--epochs", type=int, default=300,
                        help="Jumlah epoch (sesuai konfigurasi TA).")
    parser.add_argument("--batch_size", type=int, default=32,
                        help="Batch size (sesuai konfigurasi TA).")
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--max_len", type=int, default=200,
                        help="Panjang sekuens tetap (pad / truncate).")
    parser.add_argument("--out_model", type=str, default=None,
                        help="Path file .pth untuk menyimpan model.")
    parser.add_argument("--cpu", action="store_true",
                        help="Paksa pakai CPU walaupun ada GPU.")

    args = parser.parse_args()
    train_model(args)

if __name__ == "__main__":
    main()
