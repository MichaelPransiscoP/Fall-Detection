import numpy as np
import os
import glob

def cek_npz_folder(folder):
    npz_files = glob.glob(os.path.join(folder, "*.npz"))
    results = []

    for path in npz_files:
        data = np.load(path)["keypoints"]

        # Ambil x dan y
        x = data[:, :, 0]
        y = data[:, :, 1]

        # Missing = x==0 dan y==0
        missing = ((x == 0) & (y == 0)).sum()
        total = x.size

        missing_ratio = missing / total

        # Tentukan status
        if missing_ratio > 0.05:   # ambang bebas, >5% terdeteksi missing banyak
            status = "MISSING"
        else:
            status = "INTERPOLATED"

        results.append((path, data.shape, missing_ratio, status))

    return results


# === SET FOLDER NPZ KAMU DI SINI ===
FALL_DIR = r"D:\evan TA\npz_body25\fall"
NON_DIR  = r"D:\evan TA\npz_body25\non"

print("\n=== CEK FOLDER FALL ===")
fall_results = cek_npz_folder(FALL_DIR)
for path, shape, ratio, status in fall_results:
    print(f"{os.path.basename(path):40}  shape={shape}  missing_ratio={ratio:.4f}  [{status}]")

print("\n=== CEK FOLDER NON ===")
non_results = cek_npz_folder(NON_DIR)
for path, shape, ratio, status in non_results:
    print(f"{os.path.basename(path):40}  shape={shape}  missing_ratio={ratio:.4f}  [{status}]")

print("\n=== SELESAI ===")
