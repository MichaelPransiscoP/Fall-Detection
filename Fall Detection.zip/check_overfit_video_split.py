import os
import glob
import argparse
import random
from typing import List, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pack_padded_sequence


# ============================================================
# 1. Dataset NPZ (sama konsep dengan one4.py)
# ============================================================

class NpzSequenceDataset(Dataset):
    """
    Membaca file NPZ:
      - key 'keypoints' shape (T, K, 3)
      - gunakan channel x,y -> (T, K*2)
      - pad / truncate ke panjang max_len
    """

    def __init__(self, files: List[str], labels: List[int], max_len: int = 400):
        if len(files) != len(labels):
            raise ValueError("files dan labels harus sama panjang.")

        self.files = files
        self.labels = labels
        self.max_len = max_len

        # cek 1 contoh untuk dapatkan input_size
        sample = np.load(self.files[0])["keypoints"]
        T, K, C = sample.shape
        self.K = K
        self.input_size = K * 2  # x,y saja

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        path = self.files[idx]
        label = self.labels[idx]

        data = np.load(path)["keypoints"]  # (T, K, 3)
        T, K, C = data.shape

        # ambil x,y
        xy = data[:, :, :2]  # (T, K, 2)
        xy = xy.reshape(T, K * 2)  # (T, K*2)

        # simpan panjang asli (setelah dibatasi max_len)
        orig_len = min(T, self.max_len)

        # pad / truncate
        if T > self.max_len:
            xy = xy[: self.max_len, :]
        else:
            pad_len = self.max_len - T
            if pad_len > 0:
                pad = np.zeros((pad_len, K * 2), dtype=xy.dtype)
                xy = np.concatenate([xy, pad], axis=0)

        seq = torch.from_numpy(xy).float()           # (max_len, K*2)
        length = torch.tensor(orig_len, dtype=torch.long)
        label_t = torch.tensor(label, dtype=torch.float32)

        return seq, length, label_t


# ============================================================
# 2. Collate function
# ============================================================

def collate_fn(batch):
    """
    batch: list of (seq, length, label)
    """
    seqs, lengths, labels = zip(*batch)
    seqs = torch.stack(seqs, dim=0)           # (B, T, F)
    lengths = torch.stack(lengths, dim=0)     # (B,)
    labels = torch.stack(labels, dim=0)       # (B,)
    return seqs, lengths, labels


# ============================================================
# 3. Model LSTM
# ============================================================

class LSTMClassifier(nn.Module):
    def __init__(self, input_size: int, hidden_size: int = 256, dropout: float = 0.5):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            batch_first=True,
            bidirectional=False,
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x, lengths):
        """
        x: (B, T, F)
        lengths: (B,)
        """
        # pack supaya LSTM tidak memproses padding
        packed = pack_padded_sequence(
            x, lengths.cpu(), batch_first=True, enforce_sorted=False
        )
        out_packed, (h_n, c_n) = self.lstm(packed)
        # ambil hidden state terakhir (layer terakhir)
        h_last = h_n[-1]               # (B, hidden)
        h_last = self.dropout(h_last)
        logits = self.fc(h_last).squeeze(1)   # (B,)
        return logits


# ============================================================
# 4. Utilitas metric & confusion matrix
# ============================================================

def calc_metrics_from_confusion(tp, tn, fp, fn):
    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total > 0 else 0.0
    sens = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    return acc, sens, spec


def evaluate(model, loader, device, threshold: float = 0.5):
    model.eval()
    total_loss = 0.0
    total_samples = 0

    criterion = nn.BCEWithLogitsLoss()

    tp = tn = fp = fn = 0

    with torch.no_grad():
        for seqs, lengths, labels in loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels = labels.to(device)

            logits = model(seqs, lengths)
            loss = criterion(logits, labels)
            total_loss += loss.item() * labels.size(0)
            total_samples += labels.size(0)

            probs = torch.sigmoid(logits)
            preds = (probs >= threshold).float()

            tp += ((preds == 1) & (labels == 1)).sum().item()
            tn += ((preds == 0) & (labels == 0)).sum().item()
            fp += ((preds == 1) & (labels == 0)).sum().item()
            fn += ((preds == 0) & (labels == 1)).sum().item()

    avg_loss = total_loss / total_samples if total_samples > 0 else 0.0
    acc, sens, spec = calc_metrics_from_confusion(tp, tn, fp, fn)
    return avg_loss, acc, sens, spec, (tp, tn, fp, fn)


# ============================================================
# 5. Split train/val/test dengan train seimbang 25-25
# ============================================================

def make_balanced_splits(
    fall_files: List[str],
    adl_files: List[str],
    train_fall: int = 25,
    train_adl: int = 25,
    seed: int = 42,
):
    """
    Mirip dengan one4.py:
      - dari total FALL dan ADL, ambil train_fall dan train_adl untuk training
      - sisa data (FALL dan ADL) digabung, di-shuffle lalu dibagi 50:50 untuk val dan test
    """
    rng = random.Random(seed)

    n_fall = len(fall_files)
    n_adl = len(adl_files)

    if train_fall > n_fall or train_adl > n_adl:
        raise ValueError(
            f"train_fall / train_adl terlalu besar. FALL={n_fall}, ADL={n_adl}"
        )

    fall_idx = list(range(n_fall))
    adl_idx = list(range(n_adl))
    rng.shuffle(fall_idx)
    rng.shuffle(adl_idx)

    train_fall_idx = fall_idx[:train_fall]
    rest_fall_idx = fall_idx[train_fall:]

    train_adl_idx = adl_idx[:train_adl]
    rest_adl_idx = adl_idx[train_adl:]

    train_files = []
    train_labels = []

    for i in train_fall_idx:
        train_files.append(fall_files[i])
        train_labels.append(1)

    for j in train_adl_idx:
        train_files.append(adl_files[j])
        train_labels.append(0)

    # sisa data -> val + test
    rest_files = []
    rest_labels = []

    for i in rest_fall_idx:
        rest_files.append(fall_files[i])
        rest_labels.append(1)

    for j in rest_adl_idx:
        rest_files.append(adl_files[j])
        rest_labels.append(0)

    rest_pairs = list(zip(rest_files, rest_labels))
    rng.shuffle(rest_pairs)

    # bagi dua
    mid = len(rest_pairs) // 2
    val_pairs = rest_pairs[:mid]
    test_pairs = rest_pairs[mid:]

    val_files = [p[0] for p in val_pairs]
    val_labels = [p[1] for p in val_pairs]

    test_files = [p[0] for p in test_pairs]
    test_labels = [p[1] for p in test_pairs]

    return (train_files, train_labels,
            val_files, val_labels,
            test_files, test_labels)


# ============================================================
# 6. Training loop (cek overfit)
# ============================================================

def train_overfit(
    model,
    train_loader,
    val_loader,
    device,
    epochs: int = 100,
    threshold: float = 0.5,
):
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_samples = 0

        tp = tn = fp = fn = 0

        for seqs, lengths, labels in train_loader:
            seqs = seqs.to(device)
            lengths = lengths.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()
            logits = model(seqs, lengths)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * labels.size(0)
            total_samples += labels.size(0)

            probs = torch.sigmoid(logits)
            preds = (probs >= threshold).float()

            tp += ((preds == 1) & (labels == 1)).sum().item()
            tn += ((preds == 0) & (labels == 0)).sum().item()
            fp += ((preds == 1) & (labels == 0)).sum().item()
            fn += ((preds == 0) & (labels == 1)).sum().item()

        train_loss = total_loss / total_samples if total_samples > 0 else 0.0
        train_acc, train_sens, train_spec = calc_metrics_from_confusion(tp, tn, fp, fn)

        val_loss, val_acc, val_sens, val_spec, (vtp, vtn, vfp, vfn) = evaluate(
            model, val_loader, device, threshold=threshold
        )

        print(
            f"Epoch {epoch:03d} | "
            f"train_loss={train_loss:.4f} acc={train_acc:.4f} "
            f"sens={train_sens:.4f} spec={train_spec:.4f} "
            f"|| val_loss={val_loss:.4f} acc={val_acc:.4f} "
            f"sens={val_sens:.4f} spec={val_spec:.4f}"
        )
        print(
            f"CM train: TP={tp} TN={tn} FP={fp} FN={fn}\n"
            f"CM val  : TP={vtp} TN={vtn} FP={vfp} FN={vfn}"
        )
        print("-" * 60)


# ============================================================
# 7. Testing split & 1-1 per video
# ============================================================

def test_split(model, loader, device, threshold: float = 0.5, split_name: str = "TEST"):
    loss, acc, sens, spec, (tp, tn, fp, fn) = evaluate(
        model, loader, device, threshold=threshold
    )
    total = tp + tn + fp + fn
    print(f"==================== {split_name} (SPLIT) ====================")
    print(
        f"{split_name} | samples={total} loss={loss:.4f} "
        f"acc={acc:.4f} sens={sens:.4f} spec={spec:.4f}"
    )
    print(f"CM {split_name.lower()}: TP={tp} TN={tn} FP={fp} FN={fn}")
    print("=" * 61)


def test_one_by_one(model, files: List[str], labels: List[int],
                    device, threshold: float = 0.5):
    model.eval()
    print("\n==================== TESTING 1–1 PER VIDEO ====================")

    correct_fall = 0
    total_fall = 0
    correct_adl = 0
    total_adl = 0

    for path, label in zip(files, labels):
        data = np.load(path)["keypoints"]
        T, K, C = data.shape
        xy = data[:, :, :2].reshape(T, K * 2)

        max_len = xy.shape[0]
        # tidak usah pad di sini, cukup pakai length T, LSTM bisa handle via pack
        seq = torch.from_numpy(xy).float().unsqueeze(0)  # (1, T, F)
        length = torch.tensor([T], dtype=torch.long)

        seq = seq.to(device)
        length = length.to(device)

        with torch.no_grad():
            logits = model(seq, length)
            prob = torch.sigmoid(logits).item()
            pred = 1 if prob >= threshold else 0

        label_str = "FALL" if label == 1 else "ADL"
        pred_str = "FALL" if pred == 1 else "ADL"
        status = "Benar" if pred == label else "Salah"

        print(
            f"{os.path.basename(path):40s} | "
            f"label={label_str:<4s} pred={pred_str:<4s} prob={prob:.4f} | {status}"
        )

        if label == 1:
            total_fall += 1
            if pred == label:
                correct_fall += 1
        else:
            total_adl += 1
            if pred == label:
                correct_adl += 1

    total_samples = total_fall + total_adl
    total_correct = correct_fall + correct_adl

    fall_acc = correct_fall / total_fall if total_fall > 0 else 0.0
    adl_acc = correct_adl / total_adl if total_adl > 0 else 0.0
    total_acc = total_correct / total_samples if total_samples > 0 else 0.0

    print("\n-------------------- RINGKASAN 1–1 --------------------")
    print(f"FALL-only | benar {correct_fall} / {total_fall}  -> acc={fall_acc:.4f}")
    print(f"ADL-only  | benar {correct_adl} / {total_adl}   -> acc={adl_acc:.4f}")
    print(f"TOTAL     | benar {total_correct} / {total_samples} -> acc={total_acc:.4f}")
    print("=" * 54)


# ============================================================
# 8. Main
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Cek overfit LSTM Fall Detection (split per-file, train 25-25)"
    )
    parser.add_argument("--fall_dir", type=str, required=True,
                        help="Folder NPZ untuk kelas FALL")
    parser.add_argument("--non_dir", type=str, required=True,
                        help="Folder NPZ untuk kelas ADL/non-fall")
    parser.add_argument("--hidden", type=int, default=256,
                        help="Hidden size LSTM")
    parser.add_argument("--epochs", type=int, default=100,
                        help="Jumlah epoch untuk training (tanpa early stopping)")
    parser.add_argument("--batch_size", type=int, default=32,
                        help="Batch size")
    parser.add_argument("--dropout", type=float, default=0.2,
                        help="Dropout di LSTM head")
    parser.add_argument("--max_len", type=int, default=400,
                        help="Panjang maksimum sequence (frame)")
    parser.add_argument("--threshold", type=float, default=0.5,
                        help="Threshold untuk klasifikasi (sigmoid)")
    parser.add_argument("--seed", type=int, default=42,
                        help="Seed random")
    parser.add_argument("--train_fall", type=int, default=25,
                        help="Jumlah sampel FALL untuk train")
    parser.add_argument("--train_adl", type=int, default=25,
                        help="Jumlah sampel ADL untuk train")
    parser.add_argument("--out_model", type=str, default="model_overfit.pth",
                        help="Path untuk menyimpan model (opsional)")

    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Gunakan device: {device}")

    # --------------------------------------------------------
    # 1) Kumpulkan file
    # --------------------------------------------------------
    fall_files = sorted(
        glob.glob(os.path.join(args.fall_dir, "*.npz"))
    )
    adl_files = sorted(
        glob.glob(os.path.join(args.non_dir, "*.npz"))
    )

    if len(fall_files) == 0 or len(adl_files) == 0:
        raise RuntimeError("Folder fall/non tidak berisi file NPZ.")

    print(f"Jumlah file: FALL={len(fall_files)} | ADL={len(adl_files)}")

    # --------------------------------------------------------
    # 2) Split balanced 25-25 untuk train, sisanya val+test
    # --------------------------------------------------------
    (train_files, train_labels,
     val_files, val_labels,
     test_files, test_labels) = make_balanced_splits(
        fall_files, adl_files,
        train_fall=args.train_fall,
        train_adl=args.train_adl,
        seed=args.seed,
    )

    print(
        f"Split: train={len(train_files)} | "
        f"val={len(val_files)} | test={len(test_files)}"
    )

    # --------------------------------------------------------
    # 3) Dataset & DataLoader
    # --------------------------------------------------------
    train_dataset = NpzSequenceDataset(train_files, train_labels, max_len=args.max_len)
    val_dataset = NpzSequenceDataset(val_files, val_labels, max_len=args.max_len)
    test_dataset = NpzSequenceDataset(test_files, test_labels, max_len=args.max_len)

    input_size = train_dataset.input_size
    print(f"Input size: {input_size}")

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,
        collate_fn=collate_fn,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        collate_fn=collate_fn,
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        collate_fn=collate_fn,
    )

    # --------------------------------------------------------
    # 4) Model
    # --------------------------------------------------------
    model = LSTMClassifier(
        input_size=input_size,
        hidden_size=args.hidden,
        dropout=args.dropout,
    ).to(device)

    # --------------------------------------------------------
    # 5) Training (cek overfit)
    # --------------------------------------------------------
    train_overfit(
        model,
        train_loader,
        val_loader,
        device,
        epochs=args.epochs,
        threshold=args.threshold,
    )

    # simpan model jika diminta
    if args.out_model:
        torch.save(model.state_dict(), args.out_model)
        print(f"Model disimpan ke: {args.out_model}")

    # --------------------------------------------------------
    # 6) Testing split & 1-1
    # --------------------------------------------------------
    test_split(model, test_loader, device, threshold=args.threshold, split_name="TEST")

    test_one_by_one(
        model,
        test_files,
        test_labels,
        device,
        threshold=args.threshold,
    )


if __name__ == "__main__":
    main()
